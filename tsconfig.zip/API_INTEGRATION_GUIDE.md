# Frontend API Integration Guide

## Overview

This frontend now has full API client integration with the ColdWatch IoT Dashboard backend. All components are in place to connect to the backend API.

## Files Created/Modified

### New Modules

1. **`src/app/Lib/tokenStorage.ts`** - JWT token management
   - Stores/retrieves tokens with expiration tracking
   - `storeToken()`, `getToken()`, `isTokenValid()`, `clearTokens()`

2. **`src/app/Lib/api.ts`** - Complete API client
   - All endpoint wrappers (devices, alerts, readings, settings, auth)
   - WebSocket connection helper
   - Error handling and auth header management

3. **`src/app/Lib/apiSync.ts`** - React hooks for API integration
   - `useDevicesSync()` - Sync devices with backend
   - `useAlertsSync()` - Fetch and manage alerts

### Modified Files

1. **`src/app/components/SyncBanner.tsx`** - Offline sync activation
   - Now calls `/sync` endpoint when connection is restored
   - Drains ActionQueue to backend properly

## Configuration

Create or update ``.env.local`` in the project root:

```
VITE_API_URL=http://localhost:3000/api
```

For production:
```
VITE_API_URL=https://api.coldwatch.example.com/api
```

## Usage Examples

### 1. Authentication

```typescript
import { authApi } from '@/app/Lib/api';
import { getToken, clearTokens } from '@/app/Lib/tokenStorage';

// Sign up
const result = await authApi.signup({
  name: 'John Doe',
  email: 'john@example.com',
  password: 'SecurePass123',
  role: 'farmer'
});
// Token is automatically stored

// Login
const result = await authApi.login({
  identifier: 'john@example.com',
  password: 'SecurePass123'
});

// Access token
const token = getToken(); // Returns JWT or null if expired

// Logout
await authApi.logout(); // Also calls backend to clear push tokens
```

### 2. Devices Management

```typescript
import { devicesApi } from '@/app/Lib/api';

// List all devices
const { devices } = await devicesApi.list();

// Create device
const { device } = await devicesApi.create({
  name: 'Main Cooler',
  location: 'Warehouse A',
  type: 'cooler',
  tempOffset: 0,
  humidOffset: 0
});

// Update device
const { device } = await devicesApi.update(deviceId, {
  name: 'Main Cooler - Updated',
  warningTemperature: 8
});

// Delete device
await devicesApi.delete(deviceId);

// Get/rotate API key
const { apiKey } = await devicesApi.getApiKey(deviceId, { password: 'user-password' });
const { apiKey } = await devicesApi.rotateApiKey(deviceId);
```

### 3. Alerts Management

```typescript
import { alertsApi } from '@/app/Lib/api';

// Get all alerts with filtering
const { alerts, pagination } = await alertsApi.list({
  status: 'open,acknowledged',
  severity: 'critical',
  deviceId: 'device-123',
  limit: 50,
  sortBy: 'severity',
  sortOrder: 'desc'
});

// Get single alert
const { alert } = await alertsApi.get(alertId);

// Update alert status
const { alert } = await alertsApi.updateStatus(alertId, { 
  status: 'acknowledged' 
});

// Convenience methods
const { alert } = await alertsApi.acknowledge(alertId);
const { alert } = await alertsApi.resolve(alertId);

// Delete alerts
await alertsApi.delete(alertId);
await alertsApi.bulkDelete({ 
  status: 'resolved',
  from: '2026-01-01'
});
```

### 4. Readings (History)

```typescript
import { readingsApi } from '@/app/Lib/api';

// Get reading history
const { readings, count } = await readingsApi.list(deviceId, {
  limit: 100,
  from: '2026-04-01',
  to: '2026-04-24'
});

// Get latest reading
const { reading } = await readingsApi.latest(deviceId);
```

### 5. Settings Sync

```typescript
import { settingsApi } from '@/app/Lib/api';

// Get user settings
const { settings } = await settingsApi.get();

// Update settings
const { settings } = await settingsApi.update({
  warningTemperature: 8,
  criticalTemperature: 5,
  emailAlerts: true
});
```

### 6. Offline-First Actions Queue

```typescript
import { enqueueAction, drainQueue } from '@/app/Lib/ActionQueue';

// Queue an action when offline
await enqueueAction({
  type: 'UPDATE_SETTINGS',
  payload: { warningTemperature: 8 }
});

// When connection is restored, SyncBanner automatically calls drainQueue
// which sends all pending actions to the /sync endpoint
```

### 7. WebSocket Live Updates

```typescript
import { connectWebSocket } from '@/app/Lib/api';

const ws = connectWebSocket(
  deviceId,
  (data) => {
    if (data.type === 'reading') {
      console.log('New reading:', data.data);
    } else if (data.type === 'alert') {
      console.log('New alert:', data.data);
    }
  },
  (error) => console.error('WebSocket error:', error),
  () => console.log('WebSocket closed')
);

// Close when done
ws?.close();
```

## Integration Points

### In Login Page
Update `src/app/pages/Login.tsx` to use `authApi.login()` and store JWT:

```typescript
import { authApi } from '../Lib/api';
import { storeUserId } from '../Lib/tokenStorage';

// In login handler:
const result = await authApi.login({
  identifier: email,
  password: password
});

storeUserId(result.user.id);
login(result.user.email, result.user.name, result.user.id, avatar);
```

### In Devices Page
Update `src/app/pages/Devices.tsx` to use `devicesApi`:

```typescript
import { devicesApi } from '../Lib/api';

// On mount, fetch from backend:
useEffect(() => {
  const fetch = async () => {
    try {
      const { devices } = await devicesApi.list();
      // Update AppContext with backend devices
    } catch (error) {
      console.warn('Using local devices:', error);
    }
  };
  fetch();
}, []);

// When adding device:
const onCreate = async (name, location) => {
  const { device } = await devicesApi.create({ name, location, type: 'fridge' });
  addDevice(device.name, device.location);
};
```

### In Alerts Page
Update `src/app/pages/Alerts.tsx` to fetch from backend:

```typescript
import { alertsApi } from '../Lib/api';

// On mount:
useEffect(() => {
  const fetch = async () => {
    try {
      const { alerts } = await alertsApi.list({
        limit: 50,
        sortBy: 'createdAt',
        sortOrder: 'desc'
      });
      // Use backend alerts instead of simulated ones
    } catch (error) {
      console.warn('Using local alerts:', error);
    }
  };
  fetch();
}, []);

// When acknowledging:
const onAcknowledge = async (alertId) => {
  await alertsApi.acknowledge(alertId);
  acknowledgeAlert(alertId);
};
```

## Error Handling

All API calls can throw `ApiError`:

```typescript
import { alertsApi, type ApiError } from '@/app/Lib/api';

try {
  const { alerts } = await alertsApi.list();
} catch (error: any) {
  const apiError = error as ApiError;
  console.error(`[${apiError.status}] ${apiError.error}`);
  console.error('Details:', apiError.details);
  
  // Specific error handling
  if (apiError.status === 401) {
    // Token expired or invalid - redirect to login
    clearTokens();
  } else if (apiError.status === 400) {
    // Validation error
    showValidationErrors(apiError.details);
  }
}
```

## Offline-First Workflow

1. **User goes offline** - API calls fail
2. **Actions are queued** - ActionQueue stores in IndexedDB
3. **User comes back online** - SyncBanner detects connection
4. **Queue drains** - All queued actions sent to `/sync`
5. **Backend processes** - Routes each action to appropriate endpoint
6. **Success feedback** - SyncBanner shows "Changes synced"

## Next Steps

1. **Update Login Page** - Use `authApi.login()` with JWT storage
2. **Update Devices Page** - Fetch from `devicesApi`
3. **Update Alerts Page** - Fetch from `alertsApi`
4. **Update Settings Page** - Use `settingsApi`
5. **Add WebSocket** - Real-time updates in Dashboard
6. **Test Offline Flow** - Verify sync works when connection returns

## Environment Variables

Required for development:

```bash
# Backend API URL (defaults to http://localhost:3000/api)
VITE_API_URL=http://localhost:3000/api
```

## Testing

### Manual Testing

```bash
# Start dev server with API integration
npm run dev

# Test login flow (check Network tab for /auth/login)
# Test device operations (check for POST /devices, etc)
# Test offline flow (DevTools > Network > Offline, then go online)
```

### API Endpoints Reference

All endpoints from the backend are now accessible via:
- `authApi.*` - Authentication
- `devicesApi.*` - Device management
- `alertsApi.*` - Alert management
- `readingsApi.*` - Reading history
- `settingsApi.*` - User settings
- `usersApi.*` - User profile
- `syncApi.*` - Offline action sync
- `connectWebSocket()` - Live updates

See `src/app/Lib/api.ts` for full type definitions and parameters.
